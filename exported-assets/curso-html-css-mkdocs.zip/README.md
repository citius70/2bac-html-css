# Curso HTML y CSS - Material para MkDocs

Este repositorio contiene todo el material didáctico del curso de HTML y CSS para 2º de Bachillerato.

## 🚀 Instalación

1. Instalar MkDocs y Material theme:
```bash
pip install -r requirements.txt
```

2. Ejecutar servidor local:
```bash
mkdocs serve
```

3. Abrir navegador en: http://127.0.0.1:8000/

## 📁 Estructura

```
curso-html-css/
├── docs/
│   ├── index.md
│   ├── apuntes/
│   │   ├── 01-introduccion.md
│   │   └── 02-html-basico.md
│   ├── ejercicios/
│   │   └── html-basico.md
│   ├── proyecto/
│   │   └── descripcion.md
│   └── recursos/
│       ├── html-cheatsheet.md
│       └── css-cheatsheet.md
├── mkdocs.yml
├── README.md
└── requirements.txt
```

## 📚 Contenido incluido

✅ **Apuntes teóricos**
- Módulo 1: Introducción al desarrollo web
- Módulo 2: HTML básico completo

✅ **Ejercicios prácticos**
- 13 ejercicios de HTML (básico, intermedio, avanzado)

✅ **Proyecto web progresivo**
- Descripción completa del proyecto
- 4 fases para 20 sesiones

✅ **Recursos de referencia**
- Cheatsheet HTML completo
- Cheatsheet CSS completo

## 📝 Despliegue

Para generar el sitio estático:
```bash
mkdocs build
```

Para desplegar en GitHub Pages:
```bash
mkdocs gh-deploy
```

## 👨‍🏫 Uso educativo

Material diseñado para:
- **Nivel**: 2º Bachillerato (estudiantes con nivel básico 2/10)
- **Duración**: 4-5 semanas (20 sesiones)
- **Formato**: Clases teóricas + práctica + proyecto

---

Creado con ❤️ para la enseñanza de HTML y CSS
